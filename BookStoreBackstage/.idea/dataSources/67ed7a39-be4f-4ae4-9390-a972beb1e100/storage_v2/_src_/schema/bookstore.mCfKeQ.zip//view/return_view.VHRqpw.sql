create view return_view as
select `bookstore`.`orderreturn`.`id`               AS `id`,
       `bookstore`.`orderreturn`.`orderId`          AS `orderId`,
       `bookstore`.`orderreturn`.`returnReason`     AS `returnReason`,
       `bookstore`.`orderreturn`.`returnCreateTime` AS `returnCreateTime`,
       `bookstore`.`orderreturn`.`returnAmount`     AS `returnAmount`,
       `bookstore`.`orderreturn`.`returnExpressNo`  AS `returnExpressNo`,
       `bookstore`.`order1`.`orderGeneratedId`      AS `orderGeneratedId`,
       `bookstore`.`order1`.`orderState`            AS `orderState`,
       `bookstore`.`order1`.`orderCreateTime`       AS `orderCreateTime`,
       `bookstore`.`order1`.`orderPayTime`          AS `orderPayTime`,
       `bookstore`.`order1`.`orderAmount`           AS `orderAmount`,
       `bookstore`.`order1`.`customerId`            AS `customerId`,
       `bookstore`.`order1`.`deliver_no`            AS `deliver_no`,
       `bookstore`.`customer`.`customerName`        AS `customerName`,
       `bookstore`.`customer`.`customerSex`         AS `customerSex`,
       `bookstore`.`customer`.`customerEmail`       AS `customerEmail`,
       `bookstore`.`customer`.`customerAddress`     AS `customerAddress`,
       `bookstore`.`customer`.`accountId`           AS `accountId`
from ((`bookstore`.`orderreturn` join `bookstore`.`order1` on ((`bookstore`.`orderreturn`.`orderId` = `bookstore`.`order1`.`id`)))
         join `bookstore`.`customer` on ((`bookstore`.`order1`.`customerId` = `bookstore`.`customer`.`id`)));

