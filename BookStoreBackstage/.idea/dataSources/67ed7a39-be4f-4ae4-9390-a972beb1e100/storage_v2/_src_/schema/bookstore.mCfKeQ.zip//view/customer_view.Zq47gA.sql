create definer = root@`%` view customer_view as
select `bookstore`.`account`.`id`               AS `id`,
       `bookstore`.`account`.`username`         AS `username`,
       `bookstore`.`account`.`password`         AS `password`,
       `bookstore`.`account`.`telephone`        AS `telephone`,
       `bookstore`.`account`.`accountType`      AS `accountType`,
       `bookstore`.`customer`.`id`              AS `customerId`,
       `bookstore`.`customer`.`customerName`    AS `customerName`,
       `bookstore`.`customer`.`customerSex`     AS `customerSex`,
       `bookstore`.`customer`.`customerEmail`   AS `customerEmail`,
       `bookstore`.`customer`.`customerAddress` AS `customerAddress`
from (`bookstore`.`account`
         join `bookstore`.`customer` on ((`bookstore`.`account`.`id` = `bookstore`.`customer`.`accountId`)));

