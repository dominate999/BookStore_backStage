create definer = root@`%` view refund_view as
select `bookstore`.`refund`.`refundCreateTime`   AS `refundCreateTime`,
       `bookstore`.`refund`.`refundReason`       AS `refundReason`,
       `bookstore`.`refund`.`refundExpectAmount` AS `refundExpectAmount`,
       `bookstore`.`order`.`orderGeneratedId`    AS `orderGeneratedId`,
       `bookstore`.`order`.`orderState`          AS `orderState`,
       `bookstore`.`order`.`orderCreateTime`     AS `orderCreateTime`,
       `bookstore`.`order`.`orderPayTime`        AS `orderPayTime`,
       `bookstore`.`order`.`orderAmount`         AS `orderAmount`,
       `bookstore`.`customer`.`customerName`     AS `customerName`,
       `bookstore`.`customer`.`customerSex`      AS `customerSex`,
       `bookstore`.`customer`.`customerEmail`    AS `customerEmail`,
       `bookstore`.`customer`.`customerAddress`  AS `customerAddress`
from ((`bookstore`.`refund` join `bookstore`.`order`)
         join `bookstore`.`customer`)
where ((`bookstore`.`refund`.`orderId` = `bookstore`.`order`.`id`) and
       (`bookstore`.`order`.`customerId` = `bookstore`.`customer`.`id`));

