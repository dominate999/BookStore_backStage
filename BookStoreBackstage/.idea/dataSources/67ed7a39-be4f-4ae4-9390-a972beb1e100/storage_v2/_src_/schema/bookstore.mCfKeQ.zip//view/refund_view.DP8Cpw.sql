create definer = root@`%` view refund_view as
select `bookstore`.`refund`.`refundCreateTime`   AS `refundCreateTime`,
       `bookstore`.`refund`.`refundReason`       AS `refundReason`,
       `bookstore`.`refund`.`refundExpectAmount` AS `refundExpectAmount`,
       `bookstore`.`order1`.`orderGeneratedId`   AS `orderGeneratedId`,
       `bookstore`.`order1`.`orderState`         AS `orderState`,
       `bookstore`.`order1`.`orderCreateTime`    AS `orderCreateTime`,
       `bookstore`.`order1`.`orderPayTime`       AS `orderPayTime`,
       `bookstore`.`order1`.`orderAmount`        AS `orderAmount`,
       `bookstore`.`customer`.`customerName`     AS `customerName`,
       `bookstore`.`customer`.`customerSex`      AS `customerSex`,
       `bookstore`.`customer`.`customerEmail`    AS `customerEmail`,
       `bookstore`.`customer`.`customerAddress`  AS `customerAddress`,
       `bookstore`.`refund`.`orderId`            AS `orderId`,
       `bookstore`.`customer`.`accountId`        AS `accountId`
from ((`bookstore`.`refund` join `bookstore`.`order1`)
         join `bookstore`.`customer`)
where ((`bookstore`.`refund`.`orderId` = `bookstore`.`order1`.`id`) and
       (`bookstore`.`order1`.`customerId` = `bookstore`.`customer`.`id`));

