create definer = root@`%` view subcategory_view as
select `bookstore`.`subcategory`.`subcategoryName` AS `subcategoryName`,
       `bookstore`.`subcategory`.`id`              AS `id`,
       `bookstore`.`category`.`categoryName`       AS `categoryName`
from (`bookstore`.`category`
         join `bookstore`.`subcategory`)
where (`bookstore`.`subcategory`.`categoryId` = `bookstore`.`category`.`id`);

