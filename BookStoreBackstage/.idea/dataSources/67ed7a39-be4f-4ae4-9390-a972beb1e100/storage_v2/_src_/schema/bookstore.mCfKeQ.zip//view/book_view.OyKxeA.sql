create definer = root@`%` view book_view as
select `bookstore`.`book`.`id`                     AS `id`,
       `bookstore`.`book`.`bookName`               AS `bookName`,
       `bookstore`.`book`.`bookISBN`               AS `bookISBN`,
       `bookstore`.`book`.`bookPrice`              AS `bookPrice`,
       `bookstore`.`book`.`publisher`              AS `publisher`,
       `bookstore`.`book`.`bookAuthor`             AS `bookAuthor`,
       `bookstore`.`book`.`publishTime`            AS `publishTime`,
       `bookstore`.`book`.`bookStock`              AS `bookStock`,
       `bookstore`.`book`.`bookBlurb`              AS `bookBlurb`,
       `bookstore`.`book`.`bookPic`                AS `bookPic`,
       `bookstore`.`category`.`categoryName`       AS `categoryName`,
       `bookstore`.`subcategory`.`subcategoryName` AS `subcategoryName`,
       `bookstore`.`book`.`saleAmount`             AS `saleAmount`
from ((`bookstore`.`book` join `bookstore`.`category`)
         join `bookstore`.`subcategory`)
where ((`bookstore`.`book`.`subcategoryId` = `bookstore`.`subcategory`.`id`) and
       (`bookstore`.`category`.`id` = `bookstore`.`subcategory`.`categoryId`));

