create definer = root@`%` view x_order_view as
select `bookstore`.`order1`.`id`                AS `id`,
       `bookstore`.`order1`.`orderGeneratedId`  AS `orderGeneratedId`,
       `bookstore`.`order1`.`orderState`        AS `orderState`,
       `bookstore`.`order1`.`orderCreateTime`   AS `orderCreateTime`,
       `bookstore`.`order1`.`orderPayTime`      AS `orderPayTime`,
       `bookstore`.`order1`.`orderAmount`       AS `orderAmount`,
       `bookstore`.`order1`.`customerId`        AS `customerId`,
       `bookstore`.`customer`.`customerName`    AS `customerName`,
       `bookstore`.`customer`.`customerSex`     AS `customerSex`,
       `bookstore`.`customer`.`customerEmail`   AS `customerEmail`,
       `bookstore`.`customer`.`customerAddress` AS `customerAddress`,
       `bookstore`.`customer`.`accountId`       AS `accountId`,
       `bookstore`.`order1`.`deliver_no`        AS `deliver_no`
from (`bookstore`.`order1`
         join `bookstore`.`customer`)
where (`bookstore`.`order1`.`customerId` = `bookstore`.`customer`.`id`);

