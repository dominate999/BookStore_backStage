create view orderitem_view as
select `bookstore`.`orderitem`.`id`              AS `id`,
       `bookstore`.`orderitem`.`bookId`          AS `bookId`,
       `bookstore`.`orderitem`.`orderItemAmount` AS `orderItemAmount`,
       `bookstore`.`orderitem`.`bookQuantity`    AS `bookQuantity`,
       `bookstore`.`orderitem`.`evaluateId`      AS `evaluateId`,
       `bookstore`.`orderitem`.`orderId`         AS `orderId`,
       `book_view`.`bookName`                    AS `bookName`,
       `book_view`.`bookISBN`                    AS `bookISBN`,
       `book_view`.`bookPrice`                   AS `bookPrice`,
       `book_view`.`publisher`                   AS `publisher`,
       `book_view`.`bookAuthor`                  AS `bookAuthor`,
       `book_view`.`publishTime`                 AS `publishTime`,
       `book_view`.`bookStock`                   AS `bookStock`,
       `book_view`.`bookBlurb`                   AS `bookBlurb`,
       `book_view`.`bookPic`                     AS `bookPic`,
       `book_view`.`categoryName`                AS `categoryName`,
       `book_view`.`subcategoryName`             AS `subcategoryName`
from (`bookstore`.`orderitem`
         join `bookstore`.`book_view` on ((`bookstore`.`orderitem`.`bookId` = `book_view`.`id`)));

