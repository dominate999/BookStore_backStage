create view order_view as
select `bookstore`.`order`.`orderGeneratedId`    AS `orderGeneratedId`,
       `bookstore`.`order`.`orderState`          AS `orderState`,
       `bookstore`.`order`.`orderCreateTime`     AS `orderCreateTime`,
       `bookstore`.`order`.`orderPayTime`        AS `orderPayTime`,
       `bookstore`.`order`.`orderAmount`         AS `orderAmount`,
       `bookstore`.`customer`.`customerName`     AS `customerName`,
       `bookstore`.`customer`.`customerSex`      AS `customerSex`,
       `bookstore`.`customer`.`customerEmail`    AS `customerEmail`,
       `bookstore`.`customer`.`customerAddress`  AS `customerAddress`,
       `bookstore`.`orderitem`.`orderItemAmount` AS `orderItemAmount`,
       `bookstore`.`orderitem`.`bookQuantity`    AS `bookQuantity`,
       `bookstore`.`orderitem`.`evaluateId`      AS `evaluateId`,
       `bookstore`.`order`.`id`                  AS `id`,
       `bookstore`.`book`.`bookName`             AS `bookName`,
       `bookstore`.`book`.`bookISBN`             AS `bookISBN`,
       `bookstore`.`book`.`bookPrice`            AS `bookPrice`,
       `bookstore`.`book`.`publisher`            AS `publisher`,
       `bookstore`.`book`.`bookAuthor`           AS `bookAuthor`,
       `bookstore`.`book`.`publishTime`          AS `publishTime`,
       `bookstore`.`book`.`bookBlurb`            AS `bookBlurb`,
       `bookstore`.`book`.`bookPic`              AS `bookPic`,
       `bookstore`.`orderitem`.`bookId`          AS `bookId`
from (((`bookstore`.`order` join `bookstore`.`orderitem`) join `bookstore`.`book`)
         join `bookstore`.`customer`)
where ((`bookstore`.`order`.`customerId` = `bookstore`.`customer`.`id`) and
       (`bookstore`.`orderitem`.`bookId` = `bookstore`.`book`.`id`) and
       (`bookstore`.`orderitem`.`orderId` = `bookstore`.`order`.`id`));

