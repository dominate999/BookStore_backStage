create definer = root@`%` view order_view as
select `bookstore`.`order1`.`orderGeneratedId`   AS `orderGeneratedId`,
       `bookstore`.`order1`.`orderState`         AS `orderState`,
       `bookstore`.`order1`.`orderCreateTime`    AS `orderCreateTime`,
       `bookstore`.`order1`.`orderPayTime`       AS `orderPayTime`,
       `bookstore`.`order1`.`orderAmount`        AS `orderAmount`,
       `bookstore`.`customer`.`customerName`     AS `customerName`,
       `bookstore`.`customer`.`customerSex`      AS `customerSex`,
       `bookstore`.`customer`.`customerEmail`    AS `customerEmail`,
       `bookstore`.`customer`.`customerAddress`  AS `customerAddress`,
       `bookstore`.`orderitem`.`orderItemAmount` AS `orderItemAmount`,
       `bookstore`.`orderitem`.`bookQuantity`    AS `bookQuantity`,
       `bookstore`.`orderitem`.`evaluateId`      AS `evaluateId`,
       `bookstore`.`order1`.`id`                 AS `id`,
       `bookstore`.`book`.`bookName`             AS `bookName`,
       `bookstore`.`book`.`bookISBN`             AS `bookISBN`,
       `bookstore`.`book`.`bookPrice`            AS `bookPrice`,
       `bookstore`.`book`.`publisher`            AS `publisher`,
       `bookstore`.`book`.`bookAuthor`           AS `bookAuthor`,
       `bookstore`.`book`.`publishTime`          AS `publishTime`,
       `bookstore`.`book`.`bookBlurb`            AS `bookBlurb`,
       `bookstore`.`book`.`bookPic`              AS `bookPic`,
       `bookstore`.`orderitem`.`bookId`          AS `bookId`,
       `bookstore`.`customer`.`id`               AS `customerId`,
       `bookstore`.`book`.`bookStock`            AS `bookStock`,
       `bookstore`.`orderitem`.`id`              AS `orderitemId`
from (((`bookstore`.`order1` join `bookstore`.`orderitem`) join `bookstore`.`book`)
         join `bookstore`.`customer`)
where ((`bookstore`.`order1`.`customerId` = `bookstore`.`customer`.`id`) and
       (`bookstore`.`orderitem`.`bookId` = `bookstore`.`book`.`id`) and
       (`bookstore`.`orderitem`.`orderId` = `bookstore`.`order1`.`id`));

