create view cart_view as
select `bookstore`.`cart`.`id`           AS `id`,
       `bookstore`.`cart`.`customerId`   AS `customerId`,
       `bookstore`.`cart`.`bookId`       AS `bookId`,
       `bookstore`.`cart`.`cartQuantity` AS `cartQuantity`,
       `bookstore`.`cart`.`cartAmount`   AS `cartAmount`,
       `book_view`.`bookName`            AS `bookName`,
       `book_view`.`bookISBN`            AS `bookISBN`,
       `book_view`.`bookPrice`           AS `bookPrice`,
       `book_view`.`publisher`           AS `publisher`,
       `book_view`.`bookAuthor`          AS `bookAuthor`,
       `book_view`.`publishTime`         AS `publishTime`,
       `book_view`.`bookStock`           AS `bookStock`,
       `book_view`.`bookBlurb`           AS `bookBlurb`,
       `book_view`.`bookPic`             AS `bookPic`,
       `book_view`.`categoryName`        AS `categoryName`,
       `book_view`.`subcategoryName`     AS `subcategoryName`
from (`bookstore`.`cart`
         join `bookstore`.`book_view` on ((`bookstore`.`cart`.`bookId` = `book_view`.`id`)));

